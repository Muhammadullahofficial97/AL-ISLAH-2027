"""Downloads the Google Fonts used by index.html and bundles them inside the app,
so the fonts work offline. If anything fails, the app is still built (system fonts)."""
import hashlib
import html
import os
import re
import sys
import urllib.request

root = sys.argv[1]
index_path = os.path.join(root, "index.html")
fonts_dir = os.path.join(root, "fonts")

UA = ("Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36")


def get(url):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=60) as r:
        return r.read()


try:
    page = open(index_path, encoding="utf-8").read()
    links = [l for l in re.findall(r"<link[^>]*>", page)
             if "fonts.googleapis.com" in l or "fonts.gstatic.com" in l]

    css_urls = []
    for l in links:
        m = re.search(r'href="(https://fonts\.googleapis\.com/css[^"]*)"', l)
        if m:
            u = html.unescape(m.group(1))
            if u not in css_urls:
                css_urls.append(u)
    if not css_urls:
        raise RuntimeError("no Google Fonts link found in index.html")

    os.makedirs(fonts_dir, exist_ok=True)
    css_all = []
    files = {}
    for cu in css_urls:
        css = get(cu).decode("utf-8")
        for fu in set(re.findall(r"url\((https://[^)]+)\)", css)):
            if fu not in files:
                ext = os.path.splitext(fu.split("?")[0])[1] or ".woff2"
                name = hashlib.sha1(fu.encode()).hexdigest()[:12] + ext
                with open(os.path.join(fonts_dir, name), "wb") as f:
                    f.write(get(fu))
                files[fu] = name
            css = css.replace(fu, files[fu])
        css_all.append(css)

    merged = "\n".join(css_all)
    if "@font-face" not in merged or not files:
        raise RuntimeError("downloaded CSS has no fonts")
    with open(os.path.join(fonts_dir, "fonts.css"), "w", encoding="utf-8") as f:
        f.write(merged)

    for i, l in enumerate(links):
        page = page.replace(
            l, '<link rel="stylesheet" href="fonts/fonts.css">' if i == 0 else "", 1)
    with open(index_path, "w", encoding="utf-8") as f:
        f.write(page)

    total = sum(os.path.getsize(os.path.join(fonts_dir, n)) for n in files.values())
    print(f"FONTS EMBEDDED: {len(files)} files, {total // 1024} KB")
except Exception as e:  # keep the build alive
    print(f"WARNING: fonts were NOT embedded ({e}). App will use phone fonts.")
